/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex4maxvalue;

import java.util.Scanner;
/**
 *
 * @author elijah.deslouches
 */
public class Ex4MaxValue {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
	
        
		// Create exit instance & occurrence variable
		int exit = 0;
		int maxCount = 1;
		int maxNumber = 1;
		
		System.out.println("Enter an integer (0 ends the input) : ");
                int userInput = input.nextInt();
                
		while (userInput != exit) {
			userInput = input.nextInt();
			
			if (userInput > maxNumber) {
				maxNumber = userInput;
                        }
                        while (userInput == maxNumber) {
                                maxCount++;
				}
						
                                    }
			
			System.out.println("The count for the max number: " + maxNumber + " is " + maxCount);
		
    } 
    
}
