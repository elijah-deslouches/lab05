/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex1kilostopounds;

import java.util.Scanner; // User input is never recorded
import java.text.DecimalFormat;

/**
 *
 * @author elijah.deslouches
 */
public class Ex1KilosToPounds {

    
    
    public static void main(String[] args) {
        System.out.println("Kilograms       Pounds");
        System.out.println("----------------------");
        
        
        for (int i = 1; i <= 21; i++) {
                             
            if (i % 2 != 0) {
                System.out.print(i);   
                
            
            double j = 2.2;
            
            DecimalFormat df = new DecimalFormat("###.#");
            
            System.out.printf("%20s", df.format((i * j)));
            
            }
        System.out.println();
        }
       
    }
    
}
