/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex3decimaltobinary;

import java.util.Scanner;

//  * @author elijah.deslouches

public class Ex3DecimalToBinary {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        // Declare a binary string variable
        String binString = "";
        
        // input - get decimal value
        System.out.print("Enter a decimal value : ");
        int decVal = input.nextInt();
        
        // process - convert to binary
        while (decVal > 0) {
            // modulus will return either a 0 or 1 for the binary digit
            binString = decVal % 2 + binString; // keep least significant digit (LSD) on the right
            decVal = decVal / 2;
        } // end while
       
                
        // output - display the binary string
        System.out.print("The binary value is: " + binString + "\n");
    }
    
}
