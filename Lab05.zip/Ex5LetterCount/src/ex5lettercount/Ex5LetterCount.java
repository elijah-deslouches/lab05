/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex5lettercount;

import java.util.Scanner;

/**
 *
 * @author elijah.deslouches
 */
public class Ex5LetterCount {

    public static void main(String[] args) {
        
    }
    
}
