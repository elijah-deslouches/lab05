/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex2loan;

import java.util.Scanner;

/**
 *
 * @author elijah.deslouches
 */
public class Ex2Loan {


        public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Enter loan amount, for example 20000 : ");
        int loanAmount = input.nextInt();
        
        System.out.println("Enter number of years as an integer, for example 5 : ");
        int numOfYears = input.nextInt();
        
                
        System.out.println("Interest Rate     Monthly Payment     Total Payment");
           
        double annualInterestRate = 5.000;
        double w = annualInterestRate;
        
        double monthlyInterestRate = w / 100 / 12;
        double x = monthlyInterestRate;
        
        double monthlyPayment = loanAmount * x / (1 - (Math.pow(1 / (1 + x), numOfYears * 12)));
        double y = monthlyPayment;
        
        double totalPayment = y * numOfYears * 12;
        double z = totalPayment;
        
        do {
            System.out.println(w + "%       " + y + "       " + z);
            w += 0.125;
               
        } while (w <= 8);

        
    }
    
}
